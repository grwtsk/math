Compact convolution-power continuation
=====================================
Eleven proposed additive repository files. No remote commit was made in this
run. The inspected initial main was 9c0ef233; the final observed main was
46902124. The used finite-Hermite source blob is identical at both revisions.
Native Lean and full-repository checks have not run. This is written continuum
mathematics plus exact synthetic scalar checks, not an RH proof.

The substantive theorem is the compact-pole-null detector construction and its
linear negative-growth obstruction. For an alleged zero at displacement d,
liminf log(1+kappa_0(A))/A >= 2d. A source upper-growth rate alpha on any cofinal
support sequence would give d<=alpha/2. No improved source upper rate is proved.

From this extracted snapshot, or an appropriately reconciled repository root:
 python3 -B -m unittest discover -s tests -p test_weil_compact_power.py
 python3 -O -B -m unittest discover -s tests -p test_weil_compact_power.py
 python3 -B scripts/weil_compact_power.py --output /tmp/weil-power-new.json

The output path must not exist. The evaluator uses the Python standard library;
the test suite uses SymPy (tested version recorded in the environment below).
The bundle contains unchanged dependency material for reproducing the tests.
New repository payload paths are exactly those listed in NEW-FILES.json. The
included patch was roundtripped in an empty staging repository; that is not a
real checkout integration or an acceptance of Lean files. Candidate .lean.txt
files are inert evidence. No shell script installs them or changes Git refs.

Research and mathematical direction retain R.A. Jacob Martone's attribution.
Cited primary inputs and Mathlib keep their authorship and license. No PDFs
or font files are bundled. The first failed symbolic-normalization test and
its original fixture are preserved; it was not a false mathematical identity.
