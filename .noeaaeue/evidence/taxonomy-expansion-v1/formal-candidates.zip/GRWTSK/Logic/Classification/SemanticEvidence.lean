/-
Released under the repository MIT license.
Research direction: R.A. Jacob Martone.
Implementation assistance: OpenAI ChatGPT.
Candidate source: native compilation and axiom audit NOT_RUN.
-/
import GRWTSK.Logic.Classification.Types
import GRWTSK.Logic.Inference.FiniteRuleSystems

/-! # Interpreted evidence and sound expansion checkers

A reference or review label does not inhabit the interpreted proposition.
Grounded support reuses the repository's existing finite AND/OR rule system.
The mathematics grants neither current source authentication nor effect rights.
-/
set_option autoImplicit false
namespace GRWTSK.Logic.Classification
universe u v w

/-- The meaning is fixed by the consumer, not replaced by an evidence producer. -/
structure SemanticEvidence {Claim : Type u} (Meaning : Claim → Prop) (claim : Claim) where
  proved : Meaning claim

theorem SemanticEvidence.sound {Claim : Type u} {Meaning : Claim → Prop} {claim : Claim}
    (evidence : SemanticEvidence Meaning claim) : Meaning claim := evidence.proved

/-- No metadata-only certificate of a false interpretation is available. -/
theorem no_false_semantic_evidence :
    ¬ Nonempty (SemanticEvidence (fun _ : Unit => False) ()) := by
  rintro ⟨evidence⟩
  exact evidence.proved

/-- A certificate format is useful only together with its soundness theorem.
`Valid` must separately encode the actual profile's obligations. -/
structure ExpansionChecker (State : Type u) (Change : Type v)
    (Valid : State → Change → Prop) where
  Certificate : State → Change → Type w
  check : (state : State) → (change : Change) → Certificate state change → Bool
  sound : ∀ state change certificate,
    check state change certificate = true → Valid state change

/-- Boolean acceptance cannot promote a different obligation. -/
def ExpansionChecker.evidence {State : Type u} {Change : Type v}
    {Valid : State → Change → Prop} (checker : ExpansionChecker State Change Valid)
    (state : State) (change : Change) (certificate : checker.Certificate state change)
    (passed : checker.check state change certificate = true) :
    SemanticEvidence (Valid state) change := ⟨checker.sound state change certificate passed⟩

open GRWTSK.ProofHorizon.CorkscrewChamberCap in
/-- Alternative routes are OR; each route retains every AND premise.
This theorem adds no new inference engine or unchecked seed set. -/
theorem grounded_expansion_sound {Claim : Type u} {Provider : Type v}
    (routes : Provider → ProofRoute Claim) (eligible : Finset Provider)
    (Meaning : Claim → Prop)
    (rules : ∀ provider ∈ eligible,
      (∀ premise ∈ (routes provider).premises, Meaning premise) →
        Meaning (routes provider).conclusion)
    {claim : Claim} (supported : GroundedSupport routes eligible claim) : Meaning claim :=
  grounded_target routes eligible Meaning rules supported

end GRWTSK.Logic.Classification
