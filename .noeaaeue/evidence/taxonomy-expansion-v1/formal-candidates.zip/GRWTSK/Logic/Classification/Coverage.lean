/-
Released under the repository MIT license.
Research direction: R.A. Jacob Martone.
Implementation assistance: OpenAI ChatGPT.
Candidate source: native compilation and axiom audit NOT_RUN.
-/
import GRWTSK.Logic.Classification.Catalogue

/-! # Finite boundary accounting is distinct from classification coverage

Unresolved items can be fully accounted for. Only a classified outcome carries
an actual witness of the declared classification predicate. No statement here
identifies a finite boundary with all of mathematics.
-/
set_option autoImplicit false
namespace GRWTSK.Logic.Classification
universe u v

inductive ClassificationOutcome {Item : Type u} {Concept : Type v}
    (Corresponds : Item → Concept → Prop) (item : Item)
  | classified (concept : Concept) (witness : Corresponds item concept)
  | unresolved (reason : String)

def ClassificationOutcome.Established {Item : Type u} {Concept : Type v}
    {Corresponds : Item → Concept → Prop} {item : Item} :
    ClassificationOutcome Corresponds item → Prop
  | .classified _ _ => True
  | .unresolved _ => False

theorem ClassificationOutcome.established_has_witness {Item : Type u} {Concept : Type v}
    {Corresponds : Item → Concept → Prop} {item : Item}
    (outcome : ClassificationOutcome Corresponds item) (established : outcome.Established) :
    ∃ concept, Corresponds item concept := by
  cases outcome with
  | classified concept witness => exact ⟨concept, witness⟩
  | unresolved _ => exact False.elim established

variable {Item : Type u} {Concept : Type v} (Corresponds : Item → Concept → Prop)

abbrev ClassificationLedger := (item : Item) → Option (ClassificationOutcome Corresponds item)

def DispositionComplete (boundary : List Item) (ledger : ClassificationLedger Corresponds) : Prop :=
  ∀ item ∈ boundary, ∃ outcome, ledger item = some outcome

def ClassificationComplete (boundary : List Item) (ledger : ClassificationLedger Corresponds) : Prop :=
  ∀ item ∈ boundary, ∃ outcome, ledger item = some outcome ∧ outcome.Established

theorem classification_implies_disposition (boundary : List Item)
    (ledger : ClassificationLedger Corresponds)
    (complete : ClassificationComplete Corresponds boundary ledger) :
    DispositionComplete Corresponds boundary ledger := by
  intro item member
  rcases complete item member with ⟨outcome, recorded, _⟩
  exact ⟨outcome, recorded⟩

theorem classification_complete_sound (boundary : List Item)
    (ledger : ClassificationLedger Corresponds)
    (complete : ClassificationComplete Corresponds boundary ledger) :
    ∀ item ∈ boundary, ∃ concept, Corresponds item concept := by
  intro item member
  rcases complete item member with ⟨outcome, _, established⟩
  exact outcome.established_has_witness established

/-- Accounting for an unresolved item supplies no classification proof. -/
theorem unresolved_not_established (item : Item) (reason : String) :
    ¬ (ClassificationOutcome.unresolved (Corresponds := Corresponds)
      (item := item) reason).Established := by
  intro impossible
  exact impossible

end GRWTSK.Logic.Classification
