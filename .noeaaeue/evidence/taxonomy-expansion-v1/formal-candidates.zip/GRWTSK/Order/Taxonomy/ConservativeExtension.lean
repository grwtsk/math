/-
Released under the repository MIT license.
Research direction: R.A. Jacob Martone.
Implementation assistance: OpenAI ChatGPT.
Candidate source: native compilation and axiom audit NOT_RUN.
-/
import GRWTSK.Order.Taxonomy.Core

/-! # Address-preserving extensions of rooted taxonomies

This is inclusion of the declared node sets, not conservative extension of an
axiomatic theory. It preserves old addresses and their entire ancestry order.
It grants no source identity, classification, proof, or operational authority.
-/
set_option autoImplicit false
namespace GRWTSK.Order.Taxonomy

structure ConservativeExtension (before after : Taxonomy) where
  sameIdentity : before.id = after.id
  contains : ∀ {a : Address}, before.present a → after.present a

def ConservativeExtension.embed {before after : Taxonomy}
    (extension : ConservativeExtension before after) (node : before.Node) : after.Node :=
  ⟨node.val, extension.contains node.property⟩

@[simp] theorem ConservativeExtension.embed_val {before after : Taxonomy}
    (extension : ConservativeExtension before after) (node : before.Node) :
    (extension.embed node).val = node.val := rfl

theorem ConservativeExtension.embed_injective {before after : Taxonomy}
    (extension : ConservativeExtension before after) : Function.Injective extension.embed := by
  intro a b equal
  apply Taxonomy.Node.eq_of_val_eq
  exact congrArg (fun n : after.Node => n.val) equal

@[simp] theorem ConservativeExtension.order_iff {before after : Taxonomy}
    (extension : ConservativeExtension before after) (a b : before.Node) :
    extension.embed a ≤ extension.embed b ↔ a ≤ b := Iff.rfl

@[simp] theorem ConservativeExtension.lca_preserved {before after : Taxonomy}
    (extension : ConservativeExtension before after) (a b : before.Node) :
    extension.embed (before.lca a b) = after.lca (extension.embed a) (extension.embed b) := by
  apply Taxonomy.Node.eq_of_val_eq
  rfl

def ConservativeExtension.refl (taxonomy : Taxonomy) :
    ConservativeExtension taxonomy taxonomy := ⟨rfl, fun h => h⟩

def ConservativeExtension.trans {first middle last : Taxonomy}
    (left : ConservativeExtension first middle)
    (right : ConservativeExtension middle last) : ConservativeExtension first last where
  sameIdentity := left.sameIdentity.trans right.sameIdentity
  contains h := right.contains (left.contains h)

/-- Appending paths retains every old node, including its structural prefixes. -/
def ConservativeExtension.ofPathsAppend (before added : List Address)
    (identity oldRevision newRevision : String) :
    ConservativeExtension (ofPaths before identity oldRevision)
      (ofPaths (before ++ added) identity newRevision) where
  sameIdentity := rfl
  contains := by
    intro a h
    rcases h with h | ⟨b, hb, hab⟩
    · exact Or.inl h
    · exact Or.inr ⟨b, List.mem_append.mpr (Or.inl hb), hab⟩

end GRWTSK.Order.Taxonomy
