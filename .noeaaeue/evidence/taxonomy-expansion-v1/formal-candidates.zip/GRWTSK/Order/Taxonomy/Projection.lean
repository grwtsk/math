/-
Released under the repository MIT license.
Research direction: R.A. Jacob Martone.
Implementation assistance: OpenAI ChatGPT.
Candidate source: native compilation and axiom audit NOT_RUN.
-/
import GRWTSK.Order.Taxonomy.Polyhierarchy

/-! # A decimal tree is a navigation projection of a domain graph

Only tree ancestry is required to map to graph ancestry. The reverse implication
is deliberately absent: a preferred route may omit other valid parentage.
-/
set_option autoImplicit false
namespace GRWTSK.Order.Taxonomy
universe u

structure NavigationProjection {Domain : Type u}
    (graph : DomainGraph Domain) (tree : Taxonomy) where
  decode : tree.Node → Domain
  root_preserved : decode ⊥ = graph.root
  covers : ∀ domain, ∃ node, decode node = domain
  ancestry_sound : ∀ {a b : tree.Node}, a ≤ b → graph.Ancestor (decode a) (decode b)

theorem NavigationProjection.domain_covered {Domain : Type u}
    {graph : DomainGraph Domain} {tree : Taxonomy}
    (projection : NavigationProjection graph tree) (domain : Domain) :
    ∃ node, projection.decode node = domain := projection.covers domain

end GRWTSK.Order.Taxonomy
