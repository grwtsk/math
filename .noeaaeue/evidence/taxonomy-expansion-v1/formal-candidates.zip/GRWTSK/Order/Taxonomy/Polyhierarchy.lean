/-
Released under the repository MIT license.
Research direction: R.A. Jacob Martone.
Implementation assistance: OpenAI ChatGPT.
Candidate source: native compilation and axiom audit NOT_RUN.
-/
import GRWTSK.Order.Taxonomy.Core

/-! # Ranked domain graphs with multiple parents

A rank is an explicit acyclicity certificate. This finite-height presentation
models subject indexing, not logical implication or a mathematical subtype.
-/
set_option autoImplicit false
namespace GRWTSK.Order.Taxonomy
universe u

inductive StrictPath {Node : Type u} (edge : Node → Node → Prop) : Node → Node → Prop
  | single {a b : Node} : edge a b → StrictPath edge a b
  | append {a b c : Node} : StrictPath edge a b → edge b c → StrictPath edge a c

structure DomainGraph (Domain : Type u) where
  root : Domain
  parent : Domain → Domain → Prop
  rank : Domain → Nat
  parent_increases : ∀ {a b : Domain}, parent a b → rank a < rank b
  root_reaches : ∀ node, root = node ∨ StrictPath parent root node

theorem DomainGraph.path_increases {Domain : Type u} (graph : DomainGraph Domain)
    {a b : Domain} (path : StrictPath graph.parent a b) : graph.rank a < graph.rank b := by
  induction path with
  | single edge => exact graph.parent_increases edge
  | append _ edge earlier => exact Nat.lt_trans earlier (graph.parent_increases edge)

theorem DomainGraph.no_cycle {Domain : Type u} (graph : DomainGraph Domain)
    (node : Domain) : ¬ StrictPath graph.parent node node := by
  intro path
  exact Nat.lt_irrefl _ (graph.path_increases path)

/-- Reflexive ancestry in the subject graph need not have a unique LCA. -/
def DomainGraph.Ancestor {Domain : Type u} (graph : DomainGraph Domain)
    (a b : Domain) : Prop := a = b ∨ StrictPath graph.parent a b

end GRWTSK.Order.Taxonomy
